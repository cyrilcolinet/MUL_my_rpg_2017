ls-config
=========

Simple program to use libconfig9 configuration files in bash scripts

You can use libcongig9 files directly invoking ls-config, or in bash script
by sourcing lslib-core and then usinig simpe cfg_* functions. In this case 
You must set LS_EXEC to 1 before sourcing lslib-core

Existing error codes available in doc/ folder.

Samplne usage place in: sample/ folder.

Languages:
- english
- polish

We need some help to build packaging for direff systems, and with transtalions 
tu other languates.

Full changelog available in doc/changelog.txt
